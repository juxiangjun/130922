//
//  MessageDelegate.m
//  ims
//
//  Created by Tony Ju on 10/18/13.
//  Copyright (c) 2013 Tony Ju. All rights reserved.
//

#import "MessageDelegate.h"

@implementation MessageDelegate

@end
