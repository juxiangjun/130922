//
//  StringUtils.h
//  ims
//
//  Created by Tony Ju on 10/16/13.
//  Copyright (c) 2013 Tony Ju. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StringUtils : NSObject

+(NSString *) getUUID;
+(NSString *) getEmptyUUID;
+(NSString*) getFixedUUId;

@end
