//
//  StringUtils.m
//  ims
//
//  Created by Tony Ju on 10/16/13.
//  Copyright (c) 2013 Tony Ju. All rights reserved.
//

#import "StringUtils.h"

@implementation StringUtils

+(NSString *) getEmptyUUID {
    return @"00000-00000-00000-00000-00000-000000";
}

+(NSString*) getFixedUUId {
    return @"1b089f33-370b-11e3-82c6-685b358552a7";
}

+(NSString *) getUUID {
    NSUUID *uuid = [[NSUUID alloc] init];
    return [uuid UUIDString];
}



@end
