//
//  DateUtils.h
//  ims
//
//  Created by Tony Ju on 10/16/13.
//  Copyright (c) 2013 Tony Ju. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DateUtils : NSObject

+(NSDate *) getToday;

+(NSDate *) getNow;

+(NSDate *) getDate:(NSInteger) offset;


@end
