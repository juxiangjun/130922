//
//  AudioFileConvertor.h
//  ims
//
//  Created by Tony Ju on 10/30/13.
//  Copyright (c) 2013 Tony Ju. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface AudioFileConvertor : NSObject

+ (BOOL) exportAssetAsWaveFormat :(NSString*) filePath;
@end
