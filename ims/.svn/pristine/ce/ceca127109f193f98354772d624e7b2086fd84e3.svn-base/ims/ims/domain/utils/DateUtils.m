//
//  DateUtils.m
//  ims
//
//  Created by Tony Ju on 10/16/13.
//  Copyright (c) 2013 Tony Ju. All rights reserved.
//

#import "DateUtils.h"

@implementation DateUtils

+ (NSDate *) getDate:(NSInteger)offset {
    return NULL;
}

+(NSDate *) getNow {
    return [NSDate date];
}

+(NSDate *) getToday {
    return NULL;
}

@end
